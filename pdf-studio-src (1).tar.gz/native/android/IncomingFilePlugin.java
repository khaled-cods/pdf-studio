package com.khaledcods.pdfstudio;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Receives PDF files sent to the app ("Open with" / "Share") and hands them to the web app. */
@CapacitorPlugin(name = "IncomingFile")
public class IncomingFilePlugin extends Plugin {
    private static IncomingFilePlugin instance;
    private static JSObject pending;

    @Override
    public void load() {
        instance = this;
    }

    static void handle(Activity activity, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(action)) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(action)) {
            Object extra = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (extra instanceof Uri) uri = (Uri) extra;
        }
        if (uri == null) return;
        // mark as handled so a screen rotation does not open the same file again
        intent.setAction(Intent.ACTION_MAIN);
        final Uri fileUri = uri;
        new Thread(() -> {
            try {
                String name = "document.pdf";
                try (Cursor c = activity.getContentResolver().query(fileUri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        String n = c.getString(0);
                        if (n != null && n.length() > 0) name = n;
                    }
                } catch (Exception e) {
                    String last = fileUri.getLastPathSegment();
                    if (last != null) name = last.substring(last.lastIndexOf('/') + 1);
                }
                if (!name.toLowerCase().endsWith(".pdf")) name = name + ".pdf";
                InputStream in = activity.getContentResolver().openInputStream(fileUri);
                if (in == null) return;
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[65536];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                in.close();
                JSObject file = new JSObject();
                file.put("name", name);
                file.put("data", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                deliver(file);
            } catch (Exception e) {
                JSObject err = new JSObject();
                err.put("error", String.valueOf(e.getMessage()));
                deliver(err);
            }
        }).start();
    }

    private static synchronized void deliver(JSObject file) {
        if (instance != null) {
            instance.notifyListeners("fileOpened", file, true);
        } else {
            pending = file;
        }
    }

    @PluginMethod
    public void takePending(PluginCall call) {
        JSObject file;
        synchronized (IncomingFilePlugin.class) {
            file = pending;
            pending = null;
        }
        call.resolve(file == null ? new JSObject() : file);
    }
}
