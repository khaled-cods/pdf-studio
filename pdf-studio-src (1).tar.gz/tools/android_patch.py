#!/usr/bin/env python3
"""Runs after `npx cap sync` (Capacitor hook). Makes the Android app show up in
"Open with" / "Share" for PDF files and stamps the version from the CI run number."""
import os, re, shutil, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A=os.path.join(ROOT,"android")
if os.environ.get("CAPACITOR_PLATFORM_NAME","android")!="android" or not os.path.isdir(A):
    sys.exit(0)
java=os.path.join(A,"app/src/main/java/com/khaledcods/pdfstudio")
os.makedirs(java,exist_ok=True)
for f in ("MainActivity.java","IncomingFilePlugin.java"):
    shutil.copy(os.path.join(ROOT,"native/android",f),os.path.join(java,f))

mf=os.path.join(A,"app/src/main/AndroidManifest.xml"); m=open(mf,encoding="utf-8").read()
filters='''
            <!-- PDF Studio: open PDF files -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="content" />
                <data android:scheme="file" />
                <data android:mimeType="application/pdf" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="application/pdf" />
            </intent-filter>
'''
if "PDF Studio: open PDF files" not in m:
    i=m.index("android.intent.category.LAUNCHER"); j=m.index("</intent-filter>",i)+len("</intent-filter>")
    m=m[:j]+filters+m[j:]
    open(mf,"w",encoding="utf-8").write(m)

run=os.environ.get("GITHUB_RUN_NUMBER")
if run:
    g=os.path.join(A,"app/build.gradle"); s=open(g).read()
    s=re.sub(r"versionCode \d+","versionCode %d"%(100+int(run)),s)
    s=re.sub(r'versionName "[^"]*"','versionName "1.1.%s"'%run,s)
    open(g,"w").write(s)
print("android_patch: PDF open/share support added")
