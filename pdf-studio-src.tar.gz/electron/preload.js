const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("pdfStudioDesktop", {
  onOpenFile(cb) {
    ipcRenderer.on("open-file", (_e, f) => cb(f.name, new Uint8Array(f.data)));
    ipcRenderer.send("renderer-ready");
  }
});
