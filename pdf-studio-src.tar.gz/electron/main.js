// PDF Studio for Linux / Windows / Mac (Electron shell around the offline web app)
const { app, BrowserWindow, shell, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");

let win = null;
let ready = false;
let queue = [];

const pdfArgs = argv => argv.filter(a => /\.pdf$/i.test(a) && fs.existsSync(a));
function send(files) {
  if (!win || !ready) { queue.push(...files); return; }
  for (const f of files) {
    try { win.webContents.send("open-file", { name: path.basename(f), data: fs.readFileSync(f) }); } catch (e) {}
  }
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", (_e, argv) => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
    send(pdfArgs(argv));
  });
  ipcMain.on("renderer-ready", () => { ready = true; const q = queue; queue = []; send(q); });
  app.whenReady().then(() => {
    queue.push(...pdfArgs(process.argv));
    win = new BrowserWindow({
      width: 1280, height: 840, minWidth: 380, minHeight: 520,
      backgroundColor: "#0B1520", title: "PDF Studio",
      icon: path.join(__dirname, "icon.png"),
      autoHideMenuBar: true,
      webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false }
    });
    win.removeMenu();
    win.loadFile(path.join(__dirname, "..", "www", "index.html"));
    win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: "deny" }; });
    win.webContents.on("will-navigate", (e, url) => { if (!url.startsWith("file:")) { e.preventDefault(); shell.openExternal(url); } });
  });
  app.on("window-all-closed", () => app.quit());
}
