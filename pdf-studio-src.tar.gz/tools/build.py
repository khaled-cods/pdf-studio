#!/usr/bin/env python3
"""Builds the offline app in www/ from src/index.html.
Libraries and fonts are served from local files so the app works with no internet
(Android app, Linux app, and the installable web version)."""
import os, re, shutil, json, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NM=sys.argv[1] if len(sys.argv)>1 else os.path.join(ROOT,"node_modules")
WWW=os.path.join(ROOT,"www")
src=open(os.path.join(ROOT,"src","index.html"),encoding="utf-8").read()

# vendor libraries
V=os.path.join(WWW,"vendor"); os.makedirs(V,exist_ok=True)
libs={"pdf.min.js":"pdfjs-dist/build/pdf.min.js","pdf.worker.min.js":"pdfjs-dist/build/pdf.worker.min.js",
      "pdf-lib.min.js":"pdf-lib/dist/pdf-lib.min.js","jszip.min.js":"jszip/dist/jszip.min.js"}
for dst,s in libs.items(): shutil.copy(os.path.join(NM,s),os.path.join(V,dst))

# fonts (only the weights the app uses)
F=os.path.join(WWW,"fonts"); os.makedirs(F,exist_ok=True)
want={"noto-kufi-arabic":["400","500","600","700"],"aref-ruqaa":["400","700"],"great-vibes":["400"],"readex-pro":["600"]}
css=[]
for fam,ws in want.items():
    for w in ws:
        c=open(os.path.join(NM,"@fontsource",fam,w+".css"),encoding="utf-8").read()
        for u in set(re.findall(r"url\(\./files/([^)]+)\)",c)):
            if u.endswith(".woff2"): shutil.copy(os.path.join(NM,"@fontsource",fam,"files",u),os.path.join(F,u))
        c=re.sub(r"src:\s*url\(\./files/([^)]+\.woff2)\)\s*format\('woff2'\),\s*url\(\./files/[^)]+\.woff\)\s*format\('woff'\);",r"src: url(\1) format('woff2');",c)
        css.append(c)
open(os.path.join(F,"fonts.css"),"w",encoding="utf-8").write("\n".join(css))
leftover=re.findall(r"url\(\./files",open(os.path.join(F,"fonts.css")).read())
assert not leftover, "font css not rewritten"

h=src
h=re.sub(r'<link rel="preconnect"[^>]*>\n?','',h)
h=re.sub(r'<link rel="stylesheet" href="https://fonts\.googleapis\.com[^"]*">','<link rel="stylesheet" href="fonts/fonts.css">',h)
h=h.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js"></script>\n','')
h=h.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>','<script>window.PDFSTUDIO_WORKER="vendor/pdf.worker.min.js";</script>\n<script src="vendor/pdf.min.js"></script>')
h=h.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>','<script src="vendor/pdf-lib.min.js"></script>')
h=h.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>','<script src="vendor/jszip.min.js"></script>')
assert "cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js" not in h and "fonts.googleapis" not in h and 'src="https://' not in h, "a remote resource is still referenced"

# split head part (title, meta, styles) from the body
k=h.index('<div class="app"')
head,body=h[:k],h[k:]
pwa='''<meta name="theme-color" content="#0B1520">
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icons/icon-192.png">
<meta name="mobile-web-app-capable" content="yes">'''
sw='''<script>
if("serviceWorker" in navigator && location.protocol==="https:" && location.hostname!=="localhost" && !window.Capacitor){ addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{})); }
</script>'''
doc='<!doctype html>\n<html lang="ar" dir="rtl">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'+pwa+"\n"+head+'</head>\n<body>\n'+body+"\n"+sw+'\n</body>\n</html>\n'
open(os.path.join(WWW,"index.html"),"w",encoding="utf-8").write(doc)

# icons + manifest + service worker
I=os.path.join(WWW,"icons"); os.makedirs(I,exist_ok=True)
for s in ("192","512"): shutil.copy(os.path.join(ROOT,"assets","icons","icon-%s.png"%s),os.path.join(I,"icon-%s.png"%s))
shutil.copy(os.path.join(ROOT,"assets","icons","icon-maskable-512.png"),os.path.join(I,"icon-maskable-512.png"))
man={"name":"PDF Studio","short_name":"PDF Studio","description":"PDF reader and editor: sign, merge, split, convert and compress PDF files.",
     "lang":"ar","dir":"rtl","start_url":"./","scope":"./","display":"standalone","background_color":"#0B1520","theme_color":"#0B1520",
     "icons":[{"src":"icons/icon-192.png","sizes":"192x192","type":"image/png"},{"src":"icons/icon-512.png","sizes":"512x512","type":"image/png"},
              {"src":"icons/icon-maskable-512.png","sizes":"512x512","type":"image/png","purpose":"maskable"}],
     "file_handlers":[{"action":"./","accept":{"application/pdf":[".pdf"]}}]}
json.dump(man,open(os.path.join(WWW,"manifest.webmanifest"),"w"),ensure_ascii=False,indent=1)
files=["./","index.html","manifest.webmanifest"]+["vendor/"+x for x in libs]+["fonts/fonts.css"]+["fonts/"+x for x in sorted(os.listdir(F)) if x.endswith(".woff2")]+["icons/"+x for x in sorted(os.listdir(I))]
ver=str(abs(hash(doc))%10**8)
open(os.path.join(WWW,"sw.js"),"w").write('''const C="pdf-studio-%s";const FILES=%s;
self.addEventListener("install",e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()));});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener("fetch",e=>{ if(e.request.method!=="GET") return; e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(r=>r||fetch(e.request))); });
'''%(ver,json.dumps(files)))
print("built www/ :",len(files),"files cached for offline")
